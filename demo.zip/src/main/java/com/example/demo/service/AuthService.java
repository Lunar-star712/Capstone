package com.example.demo.service;

import com.example.demo.model.Member;
import com.example.demo.repository.MemberRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@AllArgsConstructor
public class AuthService {
    private final MemberRepository memberRepository;

    public Member login(String id, String pass) {
        return memberRepository.findByIdAndPass(id, pass);
    }

    public void register(Member member) {
        if (memberRepository.existsById(member.getId())) {
            throw new RuntimeException("ID already exists");
        }
        memberRepository.save(member);
    }

    @Transactional
    public void updateMember(Member member) {
        System.out.println("oliver486 1 : " + member);
        System.out.println("oliver486 2 : " + member.getId());
        // 1. 기존 회원 정보 조회
        Member existingMember = memberRepository.findById(member.getId())
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 회원입니다."));

        // 2. 비밀번호 변경 여부 확인
        if (member.getPass() != null && !member.getPass().isEmpty()) {
            if (!member.getPass().equals(existingMember.getPass())) {
                existingMember.setPass(member.getPass());
            }
        }

        // 3. 변경 가능한 필드 업데이트
        existingMember.setName(member.getName());
        existingMember.setBirth(member.getBirth());
        existingMember.setGender(member.getGender());
        existingMember.setInfo(member.getInfo());

        // 4. 저장 (JPA에서는 자동으로 더티체킹으로 업데이트됨)
        memberRepository.save(existingMember);
    }

    @Transactional
    public void withdrawMember(String memberId) {
        // 1. 회원 존재 여부 확인
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 회원입니다."));

        // 물리적 삭제
        memberRepository.delete(member);
    }

}