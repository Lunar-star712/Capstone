package com.example.demo.controller;

import com.example.demo.model.Member;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    @GetMapping("/home")
    public String home(Model model, HttpSession session) {
        Member member = (Member) session.getAttribute("loggedInMember");

        if (member == null) {
            return "index";
            // 로그인한 사용자만 홈페이지 접속이 가능하게 하려면, 아래를 주석 해제 하세요.
            // return "redirect:/auth/login";
        }
        model.addAttribute("member", member);
        return "index";
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/home";
    }

    //  셰프 페이지
    @GetMapping("/chef")
    public String chefPage(Model model, HttpSession session) {
        Member member = (Member) session.getAttribute("loggedInMember");

        if (member == null) {
            return "redirect:/auth/login";
        }

        model.addAttribute("member", member);
        return "chef"; // templates/chef.html
    }

    // 레시피 페이지
    @GetMapping("/recipe")
    public String recipePage(Model model, HttpSession session) {
        Member member = (Member) session.getAttribute("loggedInMember");

        if (member == null) {
            return "redirect:/auth/login";
        }

        model.addAttribute("member", member);
        return "recipe"; // templates/recipe.html
    }

    // 식당 페이지
    @GetMapping("/restaurant")
    public String restaurantPage(Model model, HttpSession session) {
        Member member = (Member) session.getAttribute("loggedInMember");

        if (member == null) {
            return "redirect:/auth/login";
        }

        model.addAttribute("member", member);
        return "restaurant"; // templates/restaurant.html
    }

    // 제철음식 페이지
    @GetMapping("/calendar")
    public String calendarPage(Model model, HttpSession session) {
        Member member = (Member) session.getAttribute("loggedInMember");

        if (member == null) {
            return "redirect:/auth/login";
        }

        model.addAttribute("member", member);
        return "calendar"; // templates/calendar.html
    }
}