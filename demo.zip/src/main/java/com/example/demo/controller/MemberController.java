package com.example.demo.controller;

import com.example.demo.service.AuthService;
import lombok.AllArgsConstructor;

import com.example.demo.model.Member;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/member")
@AllArgsConstructor
public class MemberController {
    private final AuthService authService;

    @PostMapping("/update")
    public String updateMember(@ModelAttribute Member member, HttpSession session) {
        Member s_member = (Member) session.getAttribute("loggedInMember");
        member.setId(s_member.getId());
        // 회원 정보 업데이트
        authService.updateMember(member);

        // 세션 정보 갱신
        session.setAttribute("loggedInMember", member);

        return "redirect:/home";
    }

    // 회원 탈퇴 처리 (POST)
    @GetMapping("/withdraw")
    public String withdrawMember(Model model, HttpSession session) {
        Member loginMember = (Member) session.getAttribute("loggedInMember");

        // 1. 현재 로그인한 회원 정보 확인
        if (loginMember == null) {
            throw new IllegalArgumentException("로그인이 필요합니다.");
        }

        // 3. 회원 탈퇴 처리
        authService.withdrawMember(loginMember.getId());

        // 4. 세션 무효화
        session.invalidate();

        return "redirect:/home";
    }
}
