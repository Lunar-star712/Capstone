package com.example.demo.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Chef {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long chefId;

    private String name;

    @Column(length = 2000)
    private String bio;

    private String imageUrl;

    @OneToMany(mappedBy = "chef")
    private List<Restaurant> restaurants;
}
