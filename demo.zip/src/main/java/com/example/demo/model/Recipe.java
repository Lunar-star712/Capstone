package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Recipe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long recipeId;

    private String name;
    private String season;
    private String availability;

    @ManyToOne
    @JoinColumn(name = "seasonal_food_id")
    private SeasonalFood seasonalFood;
}
