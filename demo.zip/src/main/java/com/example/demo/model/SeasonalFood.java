package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class SeasonalFood {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long seasonalFoodId;

    private String name;
    private String availability;
}
