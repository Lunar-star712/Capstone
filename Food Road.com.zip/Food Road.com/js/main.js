(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();


    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });


    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";

    $(window).on("load resize", function () {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
                function () {
                    const $this = $(this);
                    $this.addClass(showClass);
                    $this.find($dropdownToggle).attr("aria-expanded", "true");
                    $this.find($dropdownMenu).addClass(showClass);
                },
                function () {
                    const $this = $(this);
                    $this.removeClass(showClass);
                    $this.find($dropdownToggle).attr("aria-expanded", "false");
                    $this.find($dropdownMenu).removeClass(showClass);
                }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Modal Video
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        margin: 24,
        dots: true,
        loop: true,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 3
            }
        }
    });


})(jQuery);

function showSeason(season, event) {
    const contents = document.querySelectorAll('.season-content');
    contents.forEach(content => content.style.display = 'none');

    document.getElementById(season).style.display = 'block';

    // 탭 버튼 활성화 스타일 제어
    const buttons = document.querySelectorAll('.tabs button');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.currentTarget.classList.add('active');
}

document.addEventListener('DOMContentLoaded', function () {
    let currentPage = 1;
    const totalPages = document.querySelectorAll('.spring-page').length;

    const updatePage = () => {
        document.querySelectorAll('.spring-page').forEach(page => {
            const pageNum = parseInt(page.getAttribute('data-page'));
            page.style.display = pageNum === currentPage ? 'block' : 'none';
        });

        document.getElementById('currentPage').textContent = currentPage;
    };

    document.getElementById('prevBtn').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            updatePage();
        }
    });

    document.getElementById('nextBtn').addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            updatePage();
        }
    });

    updatePage();
});



// 양조장 데이터
const breweryData = {
    'sudogwon': [
        {
            id: 1,
            name: '호랑이배꼽향조제(허문세양양조합)',
            image: 'https://thesooltourism.com/ckfinder/userfiles/images/%ED%98%B8%EB%9E%91%EC%9D%B4%EB%B0%B0%EA%BC%BD%ED%96%A5%EC%A1%B0%EC%A0%9C.jpg',
            address: '(17566) 경기 안성시 죽산면 걸미로 37',
            subAddress: '호랑이배꼽향조제(허문세양양조합)',
            type: '약주, 증류주',
            contact: '031-673-0981',
            hours: '10월 ~ 4월'
        },
        {
            id: 2,
            name: '인천탁주제조제1공장 양조장',
            image: 'https://thesooltourism.com/ckfinder/userfiles/images/%EC%9D%B8%EC%B2%9C%ED%83%81%EC%A3%BC.jpg',
            address: '(21310) 인천 부평구 안남로433번길 14',
            subAddress: '인천탁주제조제1공장 양조장',
            type: '막걸리',
            contact: '010-6662-5759',
            hours: '1월 ~ 3월'
        }
    ],
    'gangwon': [
        {
            id: 3,
            name: '농업회사법인(주)홍은옥',
            image: 'https://thesooltourism.com/ckfinder/userfiles/images/%ED%99%8D%EC%9D%80%EC%98%A5.jpg',
            address: '(17926) 경기 평택시 오성면 숙성리 108',
            subAddress: '농업회사법인(주)홍은옥',
            type: '약주, 증류주',
            contact: '010-7667-7767',
            hours: '10월 ~ 3월'
        }
    ],
    'chungcheong': [
        {
            id: 4,
            name: '농업회사법인(주)술아원',
            image: 'https://thesooltourism.com/ckfinder/userfiles/images/%EC%88%A0%EC%95%84%EC%9B%90.jpg',
            address: '(12659) 경기 여주시 점동면 9-12 술아원',
            subAddress: '농업회사법인(주)술아원',
            type: '약주, 약청주, 막걸리, 기타주류',
            contact: '010-9971-1670',
            hours: '10월 ~ 4월'
        }
    ],
    'gyeongsang': [
        {
            id: 5,
            name: '농업회사법인(주)술샘',
            image: 'https://thesooltourism.com/ckfinder/userfiles/images/%EC%88%A0%EC%83%98.jpg',
            address: '(17156) 경기 용인시 처인구 양지면 죽양대로 2298-1',
            subAddress: '농업회사법인(주)술샘',
            type: '약주, 약청주, 과실주, 리큐르류',
            contact: '010-2250-3431',
            hours: '10월 ~ 3월'
        }
    ],
    'jeolla': [
        {
            id: 6,
            name: '농업회사법인 오산양주(주)',
            image: 'https://thesooltourism.com/ckfinder/userfiles/images/%EC%98%A4%EC%82%B0%EC%96%91%EC%A3%BC.jpg',
            address: '(18136) 경기 오산시 시장2로 63',
            subAddress: '농업회사법인 오산양주(주)',
            type: '약주, 약청, 증류소주, 기타주류',
            contact: '031-374-2139',
            hours: '8월 ~ 3월'
        }
    ],
    'jeju': [
        {
            id: 7,
            name: '농업회사법인 솔빛농원가비',
            image: 'https://thesooltourism.com/ckfinder/userfiles/images/%EC%86%94%EB%B9%9B%EB%86%8D%EC%9B%90%EA%B0%80%EB%B9%84.jpg',
            address: '(11101) 경기 포천시 영북면 산성호수로 335',
            subAddress: '솔빛농원가비',
            type: '약주',
            contact: '010-5245-0708',
            hours: '5월 ~ 4월'
        },
        {
            id: 8,
            name: '농업회사법인 금용양조 주식회사',
            image: 'https://thesooltourism.com/ckfinder/userfiles/images/%EA%B8%88%EC%9A%A9%EC%96%91%EC%A1%B0.jpg',
            address: '(23056) 인천 강화군 강화읍 강화대로 8',
            subAddress: '농업회사법인 금용양조 주식회사',
            type: '막걸리',
            contact: '070-4400-1931',
            hours: '2월 ~ 3월'
        }
    ]
};

// 현재 선택된 지역
let currentRegion = 'sudogwon';

// 지도 지역 클릭 이벤트 설정
document.querySelectorAll('#korea-map path').forEach(region => {
    region.addEventListener('click', function () {
        const regionId = this.getAttribute('id');
        currentRegion = regionId;
        updatePlaceList(regionId);

        // 지역 타이틀 업데이트
        const regionNames = {
            'sudogwon': '수도권',
            'gangwon': '강원',
            'chungcheong': '충청',
            'gyeongsang': '경상',
            'jeolla': '전라',
            'jeju': '제주'
        };
        document.getElementById('region-title').textContent = regionNames[regionId];
    });
});

// 장소 목록 업데이트 함수
function updatePlaceList(regionId) {
    const placeList = document.getElementById('place-list');
    placeList.innerHTML = ''; // 기존 목록 비우기

    const places = breweryData[regionId] || [];

    if (places.length === 0) {
        placeList.innerHTML = '<p class="text-center py-4 text-gray-500">이 지역에 등록된 양조장이 없습니다.</p>';
        return;
    }

    places.forEach(place => {
        const placeCard = document.createElement('div');
        placeCard.className = 'place-card bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden flex relative';
        placeCard.innerHTML = `
            <div class="w-1/3">
                <img src="${place.image}" alt="${place.name}" class="h-full w-full object-cover">
            </div>
            <div class="w-2/3 p-4">
                <h4 class="text-lg font-bold text-green-800 mb-2">${place.name}</h4>
                <p class="text-sm text-gray-700 mb-1"><span class="font-medium inline-block w-16">주소</span>${place.address}</p>
                <p class="text-sm text-gray-700 mb-1"><span class="font-medium inline-block w-16">상호</span>${place.subAddress}</p>
                <p class="text-sm text-gray-700 mb-1"><span class="font-medium inline-block w-16">주류</span>${place.type}</p>
                <p class="text-sm text-gray-700 mb-1"><span class="font-medium inline-block w-16">연락처</span>${place.contact}</p>
                <p class="text-sm text-gray-700"><span class="font-medium inline-block w-16">견학 시기</span>${place.hours}</p>
                <div class="card-arrow"></div>
            </div>
        `;

        // 카드 클릭 이벤트
        placeCard.addEventListener('click', () => {
            alert(`${place.name} 상세 정보로 이동합니다.`);
            // 실제 구현에서는 상세 페이지로 이동할 수 있습니다
        });

        placeList.appendChild(placeCard);
    });
}

// 검색 기능 구현
document.getElementById('search-button').addEventListener('click', searchPlaces);
document.getElementById('search-input').addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
        searchPlaces();
    }
});

function searchPlaces() {
    const searchInput = document.getElementById('search-input');
    const searchTerm = searchInput.value.toLowerCase();

    if (!searchTerm) {
        updatePlaceList(currentRegion);
        return;
    }

    const placeList = document.getElementById('place-list');
    placeList.innerHTML = ''; // 기존 목록 비우기

    // 모든 지역의 양조장 검색
    let results = [];
    for (const region in breweryData) {
        const filteredPlaces = breweryData[region].filter(place =>
            place.name.toLowerCase().includes(searchTerm) ||
            place.address.toLowerCase().includes(searchTerm) ||
            place.type.toLowerCase().includes(searchTerm)
        );
        results = [...results, ...filteredPlaces];
    }

    if (results.length === 0) {
        placeList.innerHTML = '<p class="text-center py-4 text-gray-500">검색 결과가 없습니다.</p>';
        return;
    }

    results.forEach(place => {
        const placeCard = document.createElement('div');
        placeCard.className = 'place-card bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden flex relative';
        placeCard.innerHTML = `
            <div class="w-1/3">
                <img src="${place.image}" alt="${place.name}" class="h-full w-full object-cover">
            </div>
            <div class="w-2/3 p-4">
                <h4 class="text-lg font-bold text-green-800 mb-2">${place.name}</h4>
                <p class="text-sm text-gray-700 mb-1"><span class="font-medium inline-block w-16">주소</span>${place.address}</p>
                <p class="text-sm text-gray-700 mb-1"><span class="font-medium inline-block w-16">상호</span>${place.subAddress}</p>
                <p class="text-sm text-gray-700 mb-1"><span class="font-medium inline-block w-16">주류</span>${place.type}</p>
                <p class="text-sm text-gray-700 mb-1"><span class="font-medium inline-block w-16">연락처</span>${place.contact}</p>
                <p class="text-sm text-gray-700"><span class="font-medium inline-block w-16">견학 시기</span>${place.hours}</p>
                <div class="card-arrow"></div>
            </div>
        `;

        placeList.appendChild(placeCard);
    });
}

// 초기 페이지 로드 시 수도권 양조장 목록 표시
updatePlaceList('sudogwon');
