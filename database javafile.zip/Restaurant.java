package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Restaurant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long restaurantId;

    private String name;
    private String address;
    private String openHours;
    private String imageUrl;

    @ManyToOne
    @JoinColumn(name = "chef_id")
    private Chef chef;
}
