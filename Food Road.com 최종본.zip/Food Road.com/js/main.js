(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();


    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });


    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";

    $(window).on("load resize", function () {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
                function () {
                    const $this = $(this);
                    $this.addClass(showClass);
                    $this.find($dropdownToggle).attr("aria-expanded", "true");
                    $this.find($dropdownMenu).addClass(showClass);
                },
                function () {
                    const $this = $(this);
                    $this.removeClass(showClass);
                    $this.find($dropdownToggle).attr("aria-expanded", "false");
                    $this.find($dropdownMenu).removeClass(showClass);
                }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Modal Video
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        margin: 24,
        dots: true,
        loop: true,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 3
            }
        }
    });


})(jQuery);

function showSeason(season, event) {
    const contents = document.querySelectorAll('.season-content');
    contents.forEach(content => content.style.display = 'none');

    document.getElementById(season).style.display = 'block';

    // 탭 버튼 활성화 스타일 제어
    const buttons = document.querySelectorAll('.tabs button');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.currentTarget.classList.add('active');
}

document.addEventListener('DOMContentLoaded', function () {
    let currentPage = 1;
    const totalPages = document.querySelectorAll('.spring-page').length;

    const updatePage = () => {
        document.querySelectorAll('.spring-page').forEach(page => {
            const pageNum = parseInt(page.getAttribute('data-page'));
            page.style.display = pageNum === currentPage ? 'block' : 'none';
        });

        document.getElementById('currentPage').textContent = currentPage;
    };

    document.getElementById('prevBtn').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            updatePage();
        }
    });

    document.getElementById('nextBtn').addEventListener('click', () => {
        if (currentPage < totalPages) {
            currentPage++;
            updatePage();
        }
    });

    updatePage();
});

function openChefModal(chefId) {
    const chef = chefData[chefId];
    if (!chef) return;

    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    const contactBtn = document.getElementById('contactBtn');

    modalTitle.textContent = `${chef.name} 셰프`;

    modalBody.innerHTML = `
                <div class="chef-profile">
                    <div class="chef-avatar">
                        <img src="${chef.image}" alt="${chef.name}" class="chef-detail-img">
                    </div>
                    <div class="chef-basic-info">
                        <h3>${chef.name}</h3>
                        <p><strong>레스토랑:</strong> ${chef.restaurant}</p>
                        <p><strong>위치:</strong> ${chef.location}</p>
                        <p><strong>전문 분야:</strong> ${chef.specialty}</p>
                    </div>
                </div>

                <div class="info-section">
                    <h4>셰프 소개</h4>
                    <p>${chef.description}</p>
                </div>

                <div class="info-section">
                    <h4>경력 사항</h4>
                    ${chef.career.map(item => `<div class="career-item">${item}</div>`).join('')}<br>
                </div>

                <div class="info-section">
                    <h4>수상 내역</h4>
                    ${chef.awards.map(award => `<div class="award-item">${award}</div>`).join('')}<br>
                </div>

                <div class="info-section">
                    <h4>방송 출현</h4>
                    ${chef.broadcasting.map(broadcasting => `<div class="broadcasting-item">${broadcasting}</div>`).join('')}
                </div>
            `;

    document.getElementById('modalOverlay').classList.add('active');
    document.body.style.overflow = 'hidden';
}
//모달 닫기
function closeModal() {
    document.getElementById('modalOverlay').classList.remove('active');
    document.body.style.overflow = 'auto';
}

// 모달 외부 클릭 시 닫기
document.getElementById('modalOverlay').addEventListener('click', function (e) {
    if (e.target === this) {
        closeModal();
    }
});
// 셰프 데이터
            const chefData = {
                chef1: {
                    name: "김민성",
                    restaurant: "쿠마",
                    location: "서울 영등포구",
                    image: "img/chef-1.jpg",
                    specialty: "일식",
                    description: "김민성 셰프는 서울 여의도의 해산물 오마카세 전문점 ‘쿠마(Kuma)’를 운영하는 일식 요리사로, ‘여의도 용왕’이라 불립니다. 일본에서 수련한 그는 신선한 재료 선정과 섬세한 조리로 주목받고 있으며, 친근한 소통 방식으로 손님들에게 깊은 인상을 남기고 있습니다.",
                    career: [
                        "2024 사천시 홍보대사 위촉 (임기 3년)",
                        "2023~ 유튜브 채널 '일타쿠마' 운영",
                        "2008~ '쿠마' 오너 셰프"
                    ],
                    awards: [
                        "-"
                    ],
                    broadcasting: [
                        "2024~2025《백종원의 레미제라블》"

                    ],
                },
                chef2: {
                    name: "데이비드 리",
                    restaurant: "군몽",
                    location: "서울 용산구",
                    image: "img/chef-2.jpg",
                    specialty: "양식",
                    description: "데이비드 리 셰프는 서울 한남동에서 고기 전문 레스토랑 '군몽'을 운영하고, '고기깡패'라는 별명으로 알려져 있으며, 고기의 풍미를 살리는 정교한 조리법으로 많은 이들의 사랑을 받고 있다.",
                    career: [
                        "현재 '군몽' 오너 셰프",
                        "뉴욕 미슐랭 2스타 레스토랑 오너 셰프",
                        "서울 마포구 '머지다이닝(Merge Dining)' 오너 셰프",
                        "서울 강남구 '더 미트 퀴진(The Meat Cuisine)' 총괄 셰프",
                        "미국 뉴욕의 한식 레스토랑 '오삼일(Osamil)' 총괄 셰프",
                        "미국 뉴욕의 한식 레스토랑 '반주(BarnJoo)' 총괄 셰프",
                        "미국 뉴욕의 한식 레스토랑 '곳간(Goggan)' 총괄 셰프",
                        "미국 뉴욕의 미슐랭 3스타 일식 레스토랑 '마사(Masa)' 근무",
                        "미국 뉴욕의 미슐랭 2스타 레스토랑 '피콜린(Picholine)' 근무",
                        "미국 뉴욕의 '더 스포티드 피그(The Spotted Pig)' 근무"
                    ],
                    awards: [
                        "-"
                    ],
                    broadcasting: [
                        "2024~2025《백종원의 레미제라블》",
                        "2024《흑백요리사: 요리 계급 전쟁》"
                    ],
                },
                chef3: {
                    name: "윤남노",
                    restaurant: "디핀, 디핀옥수",
                    location: "서울 중구(신당점), 서울 성동구(옥수점)",
                    image: "img/chef-3.jpg",
                    specialty: "양식",
                    description: "윤남노 셰프는 넷플릭스 '흑백요리사'에서 '요리하는 돌아이'라는 별명으로 큰 인기를 얻은 요리사이다. 현재 레스토랑 '디핀'의 헤드 셰프로 활동하고 있으며, 흑백요리사 최종 4위라는 좋은 성적을 거두며 방송계에서도 주목받고 있다.",
                    career: [
                        "현재 '디핀' 헤드 셰프",
                        "호주축산공사의 호주청정우 홍보대사",
                        "시드니 오페라 하우스 내에 위치한 '베네롱 레스토랑(Bennelong Restaurant)' 근무",
                        "서울 신라호텔 외식사업부 최연소 입사"
                    ],
                    awards: [
                        "호주축산공사 펜슬박스 요리 경연대회 수상",
                    ],
                    broadcasting: [
                        "2025《정글밥2 - 페루밥, 카리브밥》",
                        "2024~2025《백종원의 레미제라블》",
                        "2024《흑백요리사: 요리 계급 전쟁》",
                        "2016《마스터 셰프 코리아 4》"
                    ],
                },
                chef4: {
                    name: "임태훈",
                    restaurant: "도량",
                    location: "서울 영등포구",
                    image: "img/chef-4.jpg",
                    specialty: "중식",
                    description: "임태훈 셰프는 '철가방 요리사'라는 별명으로 넷플릭스 '흑백요리사'에서 큰 화제를 모은 중식 요리사이다. 현재는 중식당 '도량'의 오너 셰프로 활동하며, 배달원에서 시작해 셰프가 된 독특한 이력과 진정성 있는 요리로 많은 이들에게 희망을 주고 있다.",
                    career: [
                        "2025~ 한국중찬문화교류협회 부회장",
                        "2021~ '도량' 오너 셰프",
                        "2014~2024 '아량' 오너 셰프"
                    ],
                    awards: [
                        "2023 서울 서대문구 구정언론홍보 표창 수상",
                    ],
                    broadcasting: [
                        "2024~2025《백종원의 레미제라블》",
                        "2024《흑백요리사: 요리 계급 전쟁》"
                    ],
                },
            };